# Stream  
node API => node bindings c++ => v8+ libuv  
string => buffer => stream  
QPS 每秒查询率是对一个特定的查询服务器再规定时间内所处理流量是多少的衡量标准  

- Stream 和 Buffer 的区别  
  